import sys

def fewest_number(bricks):
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

def test():
  height = 6
  bricks = [
    [3, 5, 1, 1], [2, 3, 3, 2], [5, 5], [4, 4, 2], [1, 3, 3, 3], [1, 1, 6, 1, 1]
  ]
  n = fewest_number(bricks)
  print(n) # The output for the above example is 2.

if __name__ == '__main__':
  test()

