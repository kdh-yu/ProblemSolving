import sys

def longest_zero_sum(arr: list[int]) -> int:
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

def test():
  arr = [15, -2, 2, -8, 1, 7, 10, 23]
  # input: [15, -2, 2, -8, 1, 7, 10, 23]
  # output: 5
  n = longest_zero_sum(arr)
  print(n)

if __name__ == '__main__':
  test()

