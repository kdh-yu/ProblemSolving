#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;

int fewest_number(const vector<vector<int>>& bricks) {
    // TODO
    // Remove the following return statement, and
    // write your own solution.
    return 0;
}

void test() {
    int height = 6;
    vector<vector<int>> bricks = {
        {3, 5, 1, 1}, {2, 3, 3, 2}, {5, 5}, {4, 4, 2}, {1, 3, 3, 3}, {1, 1, 6, 1, 1}
    };
    int n = fewest_number(bricks);
    cout << n << endl;
    // The output n for the above example is 2.
}

int main() {
    test();
    return 0;
}
