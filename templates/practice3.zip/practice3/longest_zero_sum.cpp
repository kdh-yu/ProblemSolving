#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;

int longest_zero_sum(const vector<int>& arr) {
    // TODO
    // Remove the following return statement, and
    // write your own solution.
    return 0;
}

void test() {
    vector<int> arr = {15, -2, 2, -8, 1, 7, 10, 23};
    // input: {15, -2, 2, -8, 1, 7, 10, 23}
    // output: 5
    int n = longest_zero_sum(bricks);
    cout << n << endl; 
}

int main() {
    test();
    return 0;
}

