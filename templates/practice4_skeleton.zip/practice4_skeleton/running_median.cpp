#include <iostream>
#include <queue>
#include <vector>

using namespace std;

vector<double> running_median(vector<int>& nums) {
    // TODO
    // Remove the following return statement, and
    // write your own solution.
    return 0;
}

int main() {
    vector<int> nums = {2, 1, 5, 7, 2, 0, 5};

    vector<double> n = running_median(nums);

    for (double med : n) {
        cout << med << " ";
    }
    cout << endl;

    return 0;
    // The output n for the above example is 2 1.5 2 3.5 2 2 2.
}
