import heapq

def running_median(nums):
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == '__main__':
  nums = [2, 1, 5, 7, 2, 0, 5]
  output = running_median(nums)
  print(output) # The output for the above example is [2 1.5 2 3.5 2 2 2].