def one_away(s1, s2):
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == '__main__':
  lists = list(input().split())
  print(one_away(lists[0], lists[1]))