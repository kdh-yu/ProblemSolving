#include <iostream>
#include <string>
using namespace std;

bool one_away(const string &s1, const string &s2) {
    // TODO
    // Remove the following return statement, and
    // write your own solution.
    return 0;
}

int main() {
    string s1, s2;
    cin >> s1 >> s2;
    if (one_away(s1, s2)) {
        cout << "True" << endl;
    } else {
        cout << "False" << endl;
    }
    return 0;
}
